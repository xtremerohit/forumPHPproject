<?php
$serevername = "localhost";
$username = "root";
$password = "";
$database = "ihuman";

$conn = mysqli_connect($serevername, $username, $password, $database);

?>